package org.amino.ds.tree;

/**
 * type of color attached on node in red-black tree.
 *
 */
enum Color {
    RED, BLACK
}
