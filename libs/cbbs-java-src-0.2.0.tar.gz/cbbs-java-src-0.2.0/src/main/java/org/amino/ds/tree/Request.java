package org.amino.ds.tree;
/**
 * type of request attached on node.
 *
 */
enum Request {
    UP_IN, UP_OUT, REMOVAL
}

